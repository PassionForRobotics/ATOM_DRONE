
If serial port receives strs in breaks 
https://github.com/platformio/platformio-core/issues/339
